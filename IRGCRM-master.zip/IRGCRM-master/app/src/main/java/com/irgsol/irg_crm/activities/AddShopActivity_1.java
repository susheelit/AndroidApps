package com.irgsol.irg_crm.activities;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.irgsol.irg_crm.R;
import com.irgsol.irg_crm.utils.Config;
import com.irgsol.irg_crm.common.OprActivity;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;

public class AddShopActivity_1 extends AppCompatActivity {

    private androidx.appcompat.widget.AppCompatButton btnSubmit,btnUpload;
    Context context;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_shop_1);
        initView();
    }

    private void initView() {
        context = AddShopActivity_1.this;
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        OprActivity.setUpToolbarWithTitle(toolbar, "Basic Information",context );

        btnSubmit = (AppCompatButton) findViewById(R.id.btnSubmit);
        btnUpload = (AppCompatButton) findViewById(R.id.btnUpload);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OprActivity.openActivity(context, new AddShopActivity_2());
            }
        });

        btnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Config.photoDialog(context);
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        OprActivity.finishActivity(context);
        return true;
    }

    @Override
    public void onBackPressed() {
        OprActivity.finishActivity(context);
    }
}
